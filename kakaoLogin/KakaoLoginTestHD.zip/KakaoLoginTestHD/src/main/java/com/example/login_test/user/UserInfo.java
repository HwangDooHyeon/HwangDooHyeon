package com.example.login_test.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserInfo {
    private String username;
    private String email;
    private String phoneNumber;
}
